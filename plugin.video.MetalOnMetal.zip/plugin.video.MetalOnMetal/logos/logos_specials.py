def specials(params):
    return "https://lh3.googleusercontent.com/pw/ACtC-3dsK7o1DkntMB2Mz0oa9_t75EbfksTVBzwZa6pt7spRTaj4Gn9ZHJZ94BPu-sKfU4vxI4JNJ8n_WvUn4R1BIygkheSdfe_2jfNB6ws2AqU9-xFx_0Jsp0GIbJNfx730ae4W_DyCZGjc288DRGTgPxJO=w1200-h799-no"
    
def best(params):
    return "https://lh3.googleusercontent.com/pw/ACtC-3dl6AUoJX8DRXbu-Cv7YvtFak-jYO95HVJoUCPzlgSCu_zSHSn7uTLHS6RVQ9evtW2ZMo_kw-BIAZ-EVZU3xB-M8BHC_w9_TceQ7yI_Hwt0BU4lQ0Ji_HlWIPq3no7q6XxBhXFUnEU34LKLXASZDU-K=s950-no"
    #return "https://lh3.googleusercontent.com/pw/ACtC-3f-T5-Imvz8123qpDNToBgvrmQ4zMBfnzHlQqDw03RNYpf0uq0YpmF0tYPTMJyXIlpJ3rf7BF_XPi5h31YabGj-IPDl3Hn68s9BDYXpJtB0fYjm-ERjTFzjDpFcdD5yvUtc12SNUOkNlEuvS0NQ-SEX=w943-h679-no"
   

