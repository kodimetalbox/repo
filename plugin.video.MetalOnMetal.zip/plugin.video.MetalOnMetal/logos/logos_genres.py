def genres(params):
    return "https://lh3.googleusercontent.com/pw/ACtC-3esTCgba7_ixI4yN2VClVitMg9iahmyjo-e871kVFuonYhFcLvJVsrbyRsQhhjL0s-kCirwii5CVAB5vENwOA51vx3CKZCOAZDx7pDsiZt7figuFO7ASTUh_8QVP8_WJI5RGskFMI8AZ0XzAOhtD3FE=w1280-h780-no"
    


